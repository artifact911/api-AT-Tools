package polina.in.reqres;

public class GlobalVariables {

    public static final String URL = "https://reqres.in/";
    public static final String GET_USERS_PATH = "/api/users?page=2";
}
