package polina.in.reqres;

import lombok.Data;

@Data
public class Support {

    private String url;
    private String text;
}